package jbergerLab4;

public enum ToolbarPosition {
	
	LEFT, TOP, RIGHT;

}
